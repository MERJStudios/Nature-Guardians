//
//  ShopScreen.swift
//  NatureGuardians1
//
//  Created by 21-Frantz,Jonathan on 12/13/18.
//  Copyright © 2018 21-Frantz,Jonathan. All rights reserved.
//

import UIKit

class ShopScreen: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //go to quiz
    //gems
    //buy characters (compostable paper bags)
    //unlock minigames
    
    //return to main screen
    //make sure gems, etc. remains between runs
    
    //counter for max gems daily
    

}
