//
//  SettingsScreen.swift
//  NatureGuardians1
//
//  Created by 21-Frantz,Jonathan on 12/13/18.
//  Copyright © 2018 21-Frantz,Jonathan. All rights reserved.
//

import UIKit

class SettingsScreen: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    //settings
    //volume, etc.
    //make sure it works and is used in pause screen

}
